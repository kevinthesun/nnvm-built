Design Note
===========

In this part of documentation, we share the rationale for the specific choices made when designing NNVM.

.. toctree::
   :maxdepth: 2

   overview
