NNVM Change Log
===============

This file records the changes in TVM library in reverse chronological order.

## 0.8rc

- This is major change in NNVM to introduce end to end compiler stack.
  - The NNVM compiler stack ready
- Core tensor operators
- integrates compiler with TVM
- The libnnvm.a is still independent from compiler modules.

## 0.7

- NNVM graph
- Basic pass of serialization, gradient, infer_shape, place_deice, plan_memory
