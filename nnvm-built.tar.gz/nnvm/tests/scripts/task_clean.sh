#!/bin/bash
echo "Cleanup data..."
cd tvm
make clean
cd ..
make clean
