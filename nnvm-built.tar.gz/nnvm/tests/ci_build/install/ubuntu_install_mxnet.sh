pip2 install mxnet
pip3 install mxnet
