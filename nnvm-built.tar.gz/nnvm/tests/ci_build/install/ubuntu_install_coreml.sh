pip2 install coremltools
