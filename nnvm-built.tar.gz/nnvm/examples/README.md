NNVM Examples
=============
This folder contains example snippets of running NNVM Compilation.

- See also [Tutorials](../tutorials) for tutorials with detailed explainations.
