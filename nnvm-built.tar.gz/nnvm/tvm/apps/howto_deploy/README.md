How to Deploy TVM Modules
=========================
This folder contains an example on how to deploy TVM modules.
It also contains an example code to deploy with C++.

Type the following command to run the sample code under the current folder(need to build TVM first).
```bash
./run_example.sh
```

Checkout [How to Deploy TVM Modules](http://docs.tvmlang.org/how_to/deploy.html) for more information.
