## Test cases for the WebGL backend

Any test case with name `test_local_...` tests the C++ OpenGL backend on the
local OS, which can be executed automatically.

Any test case with name `test_remote_...` tests the WebGL backend within the
browser, which must be run manually. See instruction within the test.
